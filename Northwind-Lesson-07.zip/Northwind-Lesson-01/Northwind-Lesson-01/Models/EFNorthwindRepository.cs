﻿using System.Linq;

namespace Northwind.Models
{
    public class EFNorthwindRepository : INorthwindRepository
    {
        // the repository class depends on the NorthwindContext service
        // which was registered at application startup
        private NorthwindContext context;
        public EFNorthwindRepository(NorthwindContext ctx)
        {
            context = ctx;
        }
        // create IQueryable for Categories & Products
        public IQueryable<Category> Categories => context.Categories;
        public IQueryable<Product> Products => context.Products;

        public IQueryable<Discount> Discount => context.Discounts;
        public IQueryable<Contact> Contact => context.Contacts;
        public void addContact(Contact contact){
            context.Contacts.Add(contact);
            context.SaveChanges();
        }
        public IQueryable<Customer> Customer => context.Customers;
        public void addCustomer(Customer customer)
        {
            context.Customers.Add(customer);
            context.SaveChanges();
        }
    }
}

﻿using System.Linq;

namespace Northwind.Models
{
    public interface INorthwindRepository
    {
        IQueryable<Category> Categories { get; }
        IQueryable<Product> Products { get; }
        IQueryable<Discount> Discount { get; }
        IQueryable<Contact> Contact { get; }
        void addContact(Contact contact);
        IQueryable<Customer> Customer { get; }
        void addCustomer(Customer customer);
    }
}

﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Northwind.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Northwind.Controllers
{
    public class RoleAdminController:Controller
    {
        private readonly UserManager<AppUser> userManager;
        RoleManager<IdentityRole> roleManager;
        public RoleAdminController(UserManager<AppUser> userManag, RoleManager<IdentityRole> roleManag)
        {
            userManager = userManag;
            roleManager = roleManag;
        }
        public IActionResult Index()
        {
            return View(roleManager.Roles);
        }
        [HttpPost]
        public async Task<IActionResult> Create([Required]string name)
        {
            var role = new IdentityRole();
            if (ModelState.IsValid)
            {
               IdentityResult result= await roleManager.CreateAsync(new IdentityRole(name));
                if (result.Succeeded)
                {
                    RedirectToAction("Index");
                }
                else {
                    AddErrorsFromResult(result);
                }
            }
            return View(name);
        }
        public async Task<IActionResult> Delete(string id)
        {
            IdentityRole role = await roleManager.FindByIdAsync(id);
            IdentityResult result = await roleManager.DeleteAsync(role);
            if (result.Succeeded)
            {
                return RedirectToAction("Index");
            }
            else
            {
                AddErrorsFromResult(result);
            }
            return View("Index", roleManager.Roles);
        }
        private void AddErrorsFromResult(IdentityResult result)
        {
            foreach (var error in result.Errors)
            {
                ModelState.AddModelError("", error.Description);
            }
        }
    }
}

﻿$(function () {var num = 0;

    $('.form-check-input').each(function () {
        $(this).prop('checked', true);
        
        num++;
       
    });
   
   
    $('.form-check-input').on('change', function () {
        $('#' + this.id + 'Img').css('visibility', 'visible')
        $(this).is(':checked') ? ($('#' + this.id + 'Img').removeClass().addClass('animated bounceInRight')) : ($('#' + this.id + 'Img').addClass('animated bounceOutRight'));
    });
});



